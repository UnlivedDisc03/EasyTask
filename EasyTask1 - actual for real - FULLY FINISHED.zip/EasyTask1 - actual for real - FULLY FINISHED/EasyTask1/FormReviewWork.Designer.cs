﻿
namespace EasyTask1
{
    partial class FormReviewWork
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.easyTaskAdminPanel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.goBackButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.checkByUser = new System.Windows.Forms.Button();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.extensionButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.extensionPanel = new System.Windows.Forms.Panel();
            this.updateRecordButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dueDate = new System.Windows.Forms.DateTimePicker();
            this.taskIDText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nameText = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.performancePanel = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.performanceText = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.taskIDText2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonTest = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.workReviewText = new System.Windows.Forms.TextBox();
            this.panelWork = new System.Windows.Forms.Panel();
            this.taskIDForWorkView = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.extensionPanel.SuspendLayout();
            this.performancePanel.SuspendLayout();
            this.panelWork.SuspendLayout();
            this.SuspendLayout();
            // 
            // easyTaskAdminPanel
            // 
            this.easyTaskAdminPanel.AutoSize = true;
            this.easyTaskAdminPanel.BackColor = System.Drawing.SystemColors.Window;
            this.easyTaskAdminPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easyTaskAdminPanel.Location = new System.Drawing.Point(149, 16);
            this.easyTaskAdminPanel.Name = "easyTaskAdminPanel";
            this.easyTaskAdminPanel.Size = new System.Drawing.Size(503, 39);
            this.easyTaskAdminPanel.TabIndex = 65;
            this.easyTaskAdminPanel.Text = "EasyTask Admin - Review Work";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(58, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(687, 155);
            this.dataGridView1.TabIndex = 64;
            // 
            // goBackButton
            // 
            this.goBackButton.AutoSize = true;
            this.goBackButton.BackColor = System.Drawing.SystemColors.Window;
            this.goBackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.goBackButton.Location = new System.Drawing.Point(58, 26);
            this.goBackButton.Name = "goBackButton";
            this.goBackButton.Size = new System.Drawing.Size(33, 30);
            this.goBackButton.TabIndex = 63;
            this.goBackButton.Text = "◀ ";
            this.goBackButton.UseVisualStyleBackColor = false;
            this.goBackButton.Click += new System.EventHandler(this.goBackButton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Window;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(54, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(364, 20);
            this.label9.TabIndex = 72;
            this.label9.Text = "Employees name of who\'s work you wish to review:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkByUser
            // 
            this.checkByUser.AutoSize = true;
            this.checkByUser.BackColor = System.Drawing.SystemColors.Window;
            this.checkByUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.checkByUser.Location = new System.Drawing.Point(671, 227);
            this.checkByUser.Name = "checkByUser";
            this.checkByUser.Size = new System.Drawing.Size(74, 30);
            this.checkByUser.TabIndex = 71;
            this.checkByUser.Text = "Check ";
            this.checkByUser.UseVisualStyleBackColor = false;
            this.checkByUser.Click += new System.EventHandler(this.checkByUser_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.nameTextBox.Location = new System.Drawing.Point(424, 227);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(241, 27);
            this.nameTextBox.TabIndex = 70;
            // 
            // extensionButton
            // 
            this.extensionButton.AutoSize = true;
            this.extensionButton.BackColor = System.Drawing.SystemColors.Window;
            this.extensionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.extensionButton.Location = new System.Drawing.Point(59, 299);
            this.extensionButton.Name = "extensionButton";
            this.extensionButton.Size = new System.Drawing.Size(194, 30);
            this.extensionButton.TabIndex = 73;
            this.extensionButton.Text = "Grant Extension";
            this.extensionButton.UseVisualStyleBackColor = false;
            this.extensionButton.Click += new System.EventHandler(this.extensionButton_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.SystemColors.Window;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(59, 335);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 30);
            this.button1.TabIndex = 74;
            this.button1.Text = "Give performance score";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // extensionPanel
            // 
            this.extensionPanel.BackColor = System.Drawing.SystemColors.Window;
            this.extensionPanel.Controls.Add(this.updateRecordButton);
            this.extensionPanel.Controls.Add(this.label2);
            this.extensionPanel.Controls.Add(this.dueDate);
            this.extensionPanel.Controls.Add(this.taskIDText);
            this.extensionPanel.Controls.Add(this.label1);
            this.extensionPanel.Controls.Add(this.nameText);
            this.extensionPanel.Controls.Add(this.label30);
            this.extensionPanel.Location = new System.Drawing.Point(253, 263);
            this.extensionPanel.Name = "extensionPanel";
            this.extensionPanel.Size = new System.Drawing.Size(474, 175);
            this.extensionPanel.TabIndex = 75;
            // 
            // updateRecordButton
            // 
            this.updateRecordButton.AutoSize = true;
            this.updateRecordButton.BackColor = System.Drawing.SystemColors.Window;
            this.updateRecordButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.updateRecordButton.Location = new System.Drawing.Point(418, 100);
            this.updateRecordButton.Name = "updateRecordButton";
            this.updateRecordButton.Size = new System.Drawing.Size(34, 30);
            this.updateRecordButton.TabIndex = 76;
            this.updateRecordButton.Text = "▶";
            this.updateRecordButton.UseVisualStyleBackColor = false;
            this.updateRecordButton.Click += new System.EventHandler(this.updateRecordButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(21, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 20);
            this.label2.TabIndex = 80;
            this.label2.Text = "New Due Date:";
            // 
            // dueDate
            // 
            this.dueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dueDate.Location = new System.Drawing.Point(171, 100);
            this.dueDate.Name = "dueDate";
            this.dueDate.Size = new System.Drawing.Size(241, 26);
            this.dueDate.TabIndex = 79;
            // 
            // taskIDText
            // 
            this.taskIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskIDText.Location = new System.Drawing.Point(171, 54);
            this.taskIDText.Name = "taskIDText";
            this.taskIDText.Size = new System.Drawing.Size(241, 27);
            this.taskIDText.TabIndex = 78;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(21, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 20);
            this.label1.TabIndex = 77;
            this.label1.Text = "For task (Task ID):";
            // 
            // nameText
            // 
            this.nameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.nameText.Location = new System.Drawing.Point(171, 5);
            this.nameText.Name = "nameText";
            this.nameText.Size = new System.Drawing.Size(241, 27);
            this.nameText.TabIndex = 76;
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label30.Location = new System.Drawing.Point(21, 5);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(162, 56);
            this.label30.TabIndex = 25;
            this.label30.Text = "Grant extension to (Full Name):";
            // 
            // performancePanel
            // 
            this.performancePanel.BackColor = System.Drawing.SystemColors.Window;
            this.performancePanel.Controls.Add(this.button2);
            this.performancePanel.Controls.Add(this.performanceText);
            this.performancePanel.Controls.Add(this.label4);
            this.performancePanel.Controls.Add(this.taskIDText2);
            this.performancePanel.Controls.Add(this.label5);
            this.performancePanel.Location = new System.Drawing.Point(253, 263);
            this.performancePanel.Name = "performancePanel";
            this.performancePanel.Size = new System.Drawing.Size(474, 175);
            this.performancePanel.TabIndex = 81;
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.BackColor = System.Drawing.SystemColors.Window;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button2.Location = new System.Drawing.Point(418, 37);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(34, 30);
            this.button2.TabIndex = 76;
            this.button2.Text = "▶";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // performanceText
            // 
            this.performanceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.performanceText.Location = new System.Drawing.Point(211, 39);
            this.performanceText.Name = "performanceText";
            this.performanceText.Size = new System.Drawing.Size(188, 27);
            this.performanceText.TabIndex = 78;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(21, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(187, 42);
            this.label4.TabIndex = 77;
            this.label4.Text = "employees performance on task (0-100):";
            // 
            // taskIDText2
            // 
            this.taskIDText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskIDText2.Location = new System.Drawing.Point(211, 2);
            this.taskIDText2.Name = "taskIDText2";
            this.taskIDText2.Size = new System.Drawing.Size(188, 27);
            this.taskIDText2.TabIndex = 76;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(21, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 56);
            this.label5.TabIndex = 25;
            this.label5.Text = "Task to be rated (taskID):";
            // 
            // buttonTest
            // 
            this.buttonTest.AutoSize = true;
            this.buttonTest.BackColor = System.Drawing.SystemColors.Window;
            this.buttonTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonTest.Location = new System.Drawing.Point(58, 263);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new System.Drawing.Size(195, 30);
            this.buttonTest.TabIndex = 82;
            this.buttonTest.Text = "View employee comment";
            this.buttonTest.UseVisualStyleBackColor = false;
            this.buttonTest.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.AutoSize = true;
            this.button6.BackColor = System.Drawing.SystemColors.Window;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button6.Location = new System.Drawing.Point(450, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(33, 30);
            this.button6.TabIndex = 86;
            this.button6.Text = "▶";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // workReviewText
            // 
            this.workReviewText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.workReviewText.Location = new System.Drawing.Point(6, 36);
            this.workReviewText.Multiline = true;
            this.workReviewText.Name = "workReviewText";
            this.workReviewText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.workReviewText.Size = new System.Drawing.Size(474, 132);
            this.workReviewText.TabIndex = 85;
            // 
            // panelWork
            // 
            this.panelWork.BackColor = System.Drawing.SystemColors.Window;
            this.panelWork.Controls.Add(this.label3);
            this.panelWork.Controls.Add(this.taskIDForWorkView);
            this.panelWork.Controls.Add(this.workReviewText);
            this.panelWork.Controls.Add(this.button6);
            this.panelWork.Location = new System.Drawing.Point(253, 263);
            this.panelWork.Name = "panelWork";
            this.panelWork.Size = new System.Drawing.Size(483, 175);
            this.panelWork.TabIndex = 82;
            // 
            // taskIDForWorkView
            // 
            this.taskIDForWorkView.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskIDForWorkView.Location = new System.Drawing.Point(365, 2);
            this.taskIDForWorkView.Name = "taskIDForWorkView";
            this.taskIDForWorkView.Size = new System.Drawing.Size(80, 27);
            this.taskIDForWorkView.TabIndex = 83;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Window;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(6, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 20);
            this.label3.TabIndex = 83;
            this.label3.Text = "ID of comment you wish to view in detail (taskID):";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormReviewWork
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EasyTask1.Properties.Resources._1754305_Website_Background_021;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonTest);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.extensionButton);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.checkByUser);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.easyTaskAdminPanel);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.goBackButton);
            this.Controls.Add(this.panelWork);
            this.Controls.Add(this.performancePanel);
            this.Controls.Add(this.extensionPanel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormReviewWork";
            this.Text = "FormReviewWork";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.extensionPanel.ResumeLayout(false);
            this.extensionPanel.PerformLayout();
            this.performancePanel.ResumeLayout(false);
            this.performancePanel.PerformLayout();
            this.panelWork.ResumeLayout(false);
            this.panelWork.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label easyTaskAdminPanel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button goBackButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button checkByUser;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button extensionButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel extensionPanel;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox taskIDText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dueDate;
        private System.Windows.Forms.Button updateRecordButton;
        private System.Windows.Forms.Panel performancePanel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox performanceText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox taskIDText2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonTest;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox workReviewText;
        private System.Windows.Forms.Panel panelWork;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox taskIDForWorkView;
    }
}