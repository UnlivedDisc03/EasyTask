﻿
namespace EasyTask1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.easyTaskAdminPanel = new System.Windows.Forms.Label();
            this.addUserButton = new System.Windows.Forms.Button();
            this.setWorkButton = new System.Windows.Forms.Button();
            this.reviewWorkButton = new System.Windows.Forms.Button();
            this.statisticsButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // easyTaskAdminPanel
            // 
            this.easyTaskAdminPanel.AutoSize = true;
            this.easyTaskAdminPanel.BackColor = System.Drawing.SystemColors.Window;
            this.easyTaskAdminPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easyTaskAdminPanel.Location = new System.Drawing.Point(214, 9);
            this.easyTaskAdminPanel.Name = "easyTaskAdminPanel";
            this.easyTaskAdminPanel.Size = new System.Drawing.Size(370, 39);
            this.easyTaskAdminPanel.TabIndex = 0;
            this.easyTaskAdminPanel.Text = "EasyTask Admin Panel";
            // 
            // addUserButton
            // 
            this.addUserButton.AutoSize = true;
            this.addUserButton.BackColor = System.Drawing.SystemColors.Window;
            this.addUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.addUserButton.Location = new System.Drawing.Point(119, 104);
            this.addUserButton.Name = "addUserButton";
            this.addUserButton.Size = new System.Drawing.Size(192, 30);
            this.addUserButton.TabIndex = 1;
            this.addUserButton.Text = "Manage Employees";
            this.addUserButton.UseVisualStyleBackColor = false;
            this.addUserButton.Click += new System.EventHandler(this.addUserButton_Click);
            // 
            // setWorkButton
            // 
            this.setWorkButton.AutoSize = true;
            this.setWorkButton.BackColor = System.Drawing.SystemColors.Window;
            this.setWorkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.setWorkButton.Location = new System.Drawing.Point(119, 140);
            this.setWorkButton.Name = "setWorkButton";
            this.setWorkButton.Size = new System.Drawing.Size(192, 30);
            this.setWorkButton.TabIndex = 2;
            this.setWorkButton.Text = "Manage Employee Work";
            this.setWorkButton.UseVisualStyleBackColor = false;
            this.setWorkButton.Click += new System.EventHandler(this.setWorkButton_Click);
            // 
            // reviewWorkButton
            // 
            this.reviewWorkButton.AutoSize = true;
            this.reviewWorkButton.BackColor = System.Drawing.SystemColors.Window;
            this.reviewWorkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.reviewWorkButton.Location = new System.Drawing.Point(119, 176);
            this.reviewWorkButton.Name = "reviewWorkButton";
            this.reviewWorkButton.Size = new System.Drawing.Size(192, 30);
            this.reviewWorkButton.TabIndex = 3;
            this.reviewWorkButton.Text = "Review Employee work";
            this.reviewWorkButton.UseVisualStyleBackColor = false;
            this.reviewWorkButton.Click += new System.EventHandler(this.reviewWorkButton_Click);
            // 
            // statisticsButton
            // 
            this.statisticsButton.AutoSize = true;
            this.statisticsButton.BackColor = System.Drawing.SystemColors.Window;
            this.statisticsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.statisticsButton.Location = new System.Drawing.Point(119, 212);
            this.statisticsButton.Name = "statisticsButton";
            this.statisticsButton.Size = new System.Drawing.Size(192, 30);
            this.statisticsButton.TabIndex = 4;
            this.statisticsButton.Text = "Employee Statistics";
            this.statisticsButton.UseVisualStyleBackColor = false;
            this.statisticsButton.Click += new System.EventHandler(this.statisticsButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Location = new System.Drawing.Point(314, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "- Add, remove and update employees";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Window;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label2.Location = new System.Drawing.Point(315, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(271, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "- Set and change work for employees";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Window;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.Location = new System.Drawing.Point(315, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(369, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "- Review work and comment uploaded by employee";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Window;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label4.Location = new System.Drawing.Point(315, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(383, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "- Analyse various attributes of employee performance";
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.SystemColors.Window;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button3.Location = new System.Drawing.Point(119, 395);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(83, 30);
            this.button3.TabIndex = 9;
            this.button3.Text = "Log Out";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EasyTask1.Properties.Resources._1754305_Website_Background_021;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statisticsButton);
            this.Controls.Add(this.reviewWorkButton);
            this.Controls.Add(this.setWorkButton);
            this.Controls.Add(this.addUserButton);
            this.Controls.Add(this.easyTaskAdminPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label easyTaskAdminPanel;
        private System.Windows.Forms.Button addUserButton;
        private System.Windows.Forms.Button setWorkButton;
        private System.Windows.Forms.Button reviewWorkButton;
        private System.Windows.Forms.Button statisticsButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
    }
}