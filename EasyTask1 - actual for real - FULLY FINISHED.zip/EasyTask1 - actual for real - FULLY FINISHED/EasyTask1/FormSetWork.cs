﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EasyTask1
{
    public partial class FormSetWork : Form
    {
        public FormSetWork()
        {
            InitializeComponent();
            addPanel.Visible = false;
            removatePanel.Visible = false;
            updatePanelPlease.Visible = false;//sets all openable panels to be invisible
        }

        bool pleaseDontBreak = false; //an experiment from the past that I don't know if I can remove without breaking the code.

        string connectionString = "integrated security = true; data source=localhost;initial catalog=EasyTask";

        private void goBackButton_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();
            Form2.Show();//back button to go to admin page
            this.Hide();
        }

        private void searchNameButton_Click(object sender, EventArgs e)//search button
        {

            string employeeName = nameTextBox.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    if (employeeName == "")//if nothing is entered, every task from all employees is entered
                    {
                        string command = "SELECT * FROM SetWorkForm";//<---- view I made to show off my sql knoweledge. However a simpler way to do this is to manually type which columns are selected and its better in terms of database optimizationthan selecting *
                        //selects * from a view I made which ommits the last 3 collumn, that I will add in the Review Employee Work section
                        //userInputTextBox.Text = command;
                        SqlDataAdapter sqlda = new SqlDataAdapter(command, connection);
                        DataTable queriedEmployees = new DataTable();
                        sqlda.Fill(queriedEmployees);

                        dataGridView1.DataSource = queriedEmployees;
                    }
                    else
                    {
                        string command = "SELECT * FROM SetWorkForm WHERE employeeID = (SELECT employeeID FROM Employees WHERE employeeName = '" + employeeName + "')";//otherwise if a name is entered select all work records from the view where that name is.
                        //used a inner query to select from the view based on a search criteria from employees table
                        //selects * from a view I made which ommits the last 3 collumn, that I will add in the Review Employee Work section
                        //userInputTextBox.Text = command;
                        SqlDataAdapter sqlda = new SqlDataAdapter(command, connection);
                        DataTable queriedEmployees = new DataTable();
                        sqlda.Fill(queriedEmployees);

                        dataGridView1.DataSource = queriedEmployees;
                    }
                }
                catch
                {
                    MessageBox.Show("Something went wrong.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }


        private void label5_Click(object sender, EventArgs e)
        {
            string pleaseDontCrashDestroyMyWork = "true";
            if (pleaseDontCrashDestroyMyWork == "false")
            {
                pleaseDontCrashDestroyMyWork = "true";//missclick that im scared to remove lest everything might break please ignore
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string pleaseDontCrashDestroyMyWork = "true";
            if (pleaseDontCrashDestroyMyWork == "false")//missclick that im scared to remove please ignore
            {
                pleaseDontCrashDestroyMyWork = "true";
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            addPanel.Visible = true;
            removatePanel.Visible = false;
            updatePanelPlease.Visible = false;//when add button clicked the add panel is brought up
        }

        private void updateRecordButton_Click(object sender, EventArgs e)//add new task
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    DateTime getDueDate = dateTimePicker1.Value.Date; 
                    DateTime getSetDate = DateTime.Now.Date;
                    string command = "INSERT INTO WorkSet VALUES (" + taskID.Text + ", " + employeeID.Text + ", '" + taskDescription.Text + "', @getDateSet, @getDateDue, '" + setBy.Text + "', 'NO', NULL, NULL, NULL)";
                    //the admin can enter a new task for the user and the workSet table is updated
                    //taskDescription.Text = command;

                    using (SqlCommand cmd = new SqlCommand(command, connection))
                    {
                        cmd.Parameters.AddWithValue("@getDateSet", getSetDate);
                        cmd.Parameters.AddWithValue("@getDateDue", getDueDate);//adds the dates seperately
                        cmd.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void removeButton_Click(object sender, EventArgs e)
        {
            addPanel.Visible = false;//show remove panel hides rest
            removatePanel.Visible = true;
            updatePanelPlease.Visible = false;
        }

        private void removeRecordButton_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    //similarily as before I assumed the record would not be deleted due to the a referetial integrity constraint. 
                    //after research I found out the only way to preserve data on the work done in the past is to set the foreign key to null.
                    //this way the data will be kept except for which employee did it
                    string command = "DELETE FROM WorkSet WHERE taskID = " + IDWorkRemove.Text + " AND employeeID = " + nameWorkRemove.Text;
                    //deletes a record of work from the table
                    SqlCommand cmd = new SqlCommand(command, connection);
                    cmd.ExecuteNonQuery();
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void removeRecordButton_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))//THE REASON 2 OF THESE EXIST IS BECAUSE DUE TO GLITCHES, I HAD TO DELETE THE WHO PANEL FROM BEFORE. MEANING ONE OF THESE BUTTONS IS THE ORIGINAL DELETED
                //AND THE OTHER IS THE NEW VERSION THAT WORKS. DONT WANT TO DELETE PREVIOUS BUTTON AS TO NOT DESTROY MY CODE.
            {
                connection.Open();
                try
                {
                    //similarily as before I assumed the record would not be deleted due to the a referetial integrity constraint. 
                    //after research I found out the only way to preserve data on the work done in the past is to set the foreign key to null.
                    //this way the data will be kept except for which employee did it
                    string command = "DELETE FROM WorkSet WHERE taskID = " + IDWorkRemove.Text + " AND employeeID = " + nameWorkRemove.Text;
                    SqlCommand cmd = new SqlCommand(command, connection);
                    cmd.ExecuteNonQuery();
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            addPanel.Visible = false;
            removatePanel.Visible = false;
            updatePanelPlease.Visible = true;//shows update panel hides rest
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pleaseDontBreak = true;//experiment from before doesnt work
        }

        private void button1_Click_1(object sender, EventArgs e)//UPDATE BUTTON
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    DateTime extensionDue = dateTimePicker2.Value.Date;
                    string command = "UPDATE WorkSet SET taskDescription = '" + taskText2.Text + "', dateDue = @newDueDate WHERE taskID = " + taskIDText2.Text + " AND employeeID = " + employeeIDText.Text;
                    //allows the user to update an existing task that was set

                    using (SqlCommand cmd = new SqlCommand(command, connection))
                    {
                        cmd.Parameters.AddWithValue("@newDueDate", extensionDue);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}, Make sure not to include any apostrophes in your text as it interferes with database operations", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
