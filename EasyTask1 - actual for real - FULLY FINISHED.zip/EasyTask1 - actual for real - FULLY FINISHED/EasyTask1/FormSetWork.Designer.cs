﻿
namespace EasyTask1
{
    partial class FormSetWork
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.goBackButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.searchNameButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.addPanel = new System.Windows.Forms.Panel();
            this.addWorkButton = new System.Windows.Forms.Button();
            this.taskDescription = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.setBy = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.employeeID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.taskID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.easyTaskAdminPanel = new System.Windows.Forms.Label();
            this.removatePanel = new System.Windows.Forms.Panel();
            this.nameWorkRemove = new System.Windows.Forms.TextBox();
            this.IDWorkRemove = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.removeRecordButton = new System.Windows.Forms.Button();
            this.updatePanelPlease = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.taskText2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.taskIDText2 = new System.Windows.Forms.TextBox();
            this.employeeIDText = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.addPanel.SuspendLayout();
            this.removatePanel.SuspendLayout();
            this.updatePanelPlease.SuspendLayout();
            this.SuspendLayout();
            // 
            // goBackButton
            // 
            this.goBackButton.AutoSize = true;
            this.goBackButton.BackColor = System.Drawing.SystemColors.Window;
            this.goBackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.goBackButton.Location = new System.Drawing.Point(56, 18);
            this.goBackButton.Name = "goBackButton";
            this.goBackButton.Size = new System.Drawing.Size(33, 30);
            this.goBackButton.TabIndex = 11;
            this.goBackButton.Text = "◀ ";
            this.goBackButton.UseVisualStyleBackColor = false;
            this.goBackButton.Click += new System.EventHandler(this.goBackButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(56, 55);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(687, 117);
            this.dataGridView1.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Window;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(52, 185);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(378, 20);
            this.label9.TabIndex = 38;
            this.label9.Text = "Employees name of who\'s work you wish to manage:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.nameTextBox.Location = new System.Drawing.Point(430, 182);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(231, 27);
            this.nameTextBox.TabIndex = 39;
            // 
            // searchNameButton
            // 
            this.searchNameButton.AutoSize = true;
            this.searchNameButton.BackColor = System.Drawing.SystemColors.Window;
            this.searchNameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.searchNameButton.Location = new System.Drawing.Point(667, 180);
            this.searchNameButton.Name = "searchNameButton";
            this.searchNameButton.Size = new System.Drawing.Size(76, 30);
            this.searchNameButton.TabIndex = 40;
            this.searchNameButton.Text = "Search";
            this.searchNameButton.UseVisualStyleBackColor = false;
            this.searchNameButton.Click += new System.EventHandler(this.searchNameButton_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(49, 233);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 41);
            this.label1.TabIndex = 41;
            this.label1.Text = "Manage Work";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // updateButton
            // 
            this.updateButton.AutoSize = true;
            this.updateButton.BackColor = System.Drawing.SystemColors.Window;
            this.updateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.updateButton.Location = new System.Drawing.Point(54, 349);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(86, 30);
            this.updateButton.TabIndex = 44;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.AutoSize = true;
            this.removeButton.BackColor = System.Drawing.SystemColors.Window;
            this.removeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.removeButton.Location = new System.Drawing.Point(54, 313);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(86, 30);
            this.removeButton.TabIndex = 43;
            this.removeButton.Text = "Remove";
            this.removeButton.UseVisualStyleBackColor = false;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // addButton
            // 
            this.addButton.AutoSize = true;
            this.addButton.BackColor = System.Drawing.SystemColors.Window;
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.addButton.Location = new System.Drawing.Point(52, 277);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(88, 30);
            this.addButton.TabIndex = 42;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // addPanel
            // 
            this.addPanel.BackColor = System.Drawing.SystemColors.Window;
            this.addPanel.Controls.Add(this.addWorkButton);
            this.addPanel.Controls.Add(this.taskDescription);
            this.addPanel.Controls.Add(this.label6);
            this.addPanel.Controls.Add(this.setBy);
            this.addPanel.Controls.Add(this.label4);
            this.addPanel.Controls.Add(this.dateTimePicker1);
            this.addPanel.Controls.Add(this.label5);
            this.addPanel.Controls.Add(this.employeeID);
            this.addPanel.Controls.Add(this.label3);
            this.addPanel.Controls.Add(this.taskID);
            this.addPanel.Controls.Add(this.label2);
            this.addPanel.Location = new System.Drawing.Point(149, 216);
            this.addPanel.Name = "addPanel";
            this.addPanel.Size = new System.Drawing.Size(589, 231);
            this.addPanel.TabIndex = 45;
            // 
            // addWorkButton
            // 
            this.addWorkButton.AutoSize = true;
            this.addWorkButton.BackColor = System.Drawing.SystemColors.Window;
            this.addWorkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.addWorkButton.Location = new System.Drawing.Point(555, 192);
            this.addWorkButton.Name = "addWorkButton";
            this.addWorkButton.Size = new System.Drawing.Size(33, 30);
            this.addWorkButton.TabIndex = 58;
            this.addWorkButton.Text = "▶";
            this.addWorkButton.UseVisualStyleBackColor = false;
            this.addWorkButton.Click += new System.EventHandler(this.updateRecordButton_Click);
            // 
            // taskDescription
            // 
            this.taskDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskDescription.Location = new System.Drawing.Point(125, 85);
            this.taskDescription.Multiline = true;
            this.taskDescription.Name = "taskDescription";
            this.taskDescription.Size = new System.Drawing.Size(424, 137);
            this.taskDescription.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.Window;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(13, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 55);
            this.label6.TabIndex = 56;
            this.label6.Text = "Task Description";
            // 
            // setBy
            // 
            this.setBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.setBy.Location = new System.Drawing.Point(380, 47);
            this.setBy.Name = "setBy";
            this.setBy.Size = new System.Drawing.Size(169, 27);
            this.setBy.TabIndex = 54;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Window;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(296, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 20);
            this.label4.TabIndex = 55;
            this.label4.Text = "Set By";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dateTimePicker1.Location = new System.Drawing.Point(380, 11);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(169, 26);
            this.dateTimePicker1.TabIndex = 53;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Window;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(296, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 52;
            this.label5.Text = "Date Due";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // employeeID
            // 
            this.employeeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.employeeID.Location = new System.Drawing.Point(125, 47);
            this.employeeID.Name = "employeeID";
            this.employeeID.Size = new System.Drawing.Size(156, 27);
            this.employeeID.TabIndex = 47;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Window;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(13, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 20);
            this.label3.TabIndex = 48;
            this.label3.Text = "Employee ID ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // taskID
            // 
            this.taskID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskID.Location = new System.Drawing.Point(125, 14);
            this.taskID.Name = "taskID";
            this.taskID.Size = new System.Drawing.Size(156, 27);
            this.taskID.TabIndex = 46;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Window;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(13, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 46;
            this.label2.Text = "Task ID ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // easyTaskAdminPanel
            // 
            this.easyTaskAdminPanel.AutoSize = true;
            this.easyTaskAdminPanel.BackColor = System.Drawing.SystemColors.Window;
            this.easyTaskAdminPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easyTaskAdminPanel.Location = new System.Drawing.Point(158, 8);
            this.easyTaskAdminPanel.Name = "easyTaskAdminPanel";
            this.easyTaskAdminPanel.Size = new System.Drawing.Size(513, 39);
            this.easyTaskAdminPanel.TabIndex = 59;
            this.easyTaskAdminPanel.Text = "EasyTask Admin - Manage Work";
            // 
            // removatePanel
            // 
            this.removatePanel.BackColor = System.Drawing.SystemColors.Window;
            this.removatePanel.Controls.Add(this.nameWorkRemove);
            this.removatePanel.Controls.Add(this.IDWorkRemove);
            this.removatePanel.Controls.Add(this.label7);
            this.removatePanel.Controls.Add(this.label30);
            this.removatePanel.Controls.Add(this.removeRecordButton);
            this.removatePanel.Location = new System.Drawing.Point(149, 216);
            this.removatePanel.Name = "removatePanel";
            this.removatePanel.Size = new System.Drawing.Size(589, 231);
            this.removatePanel.TabIndex = 59;
            // 
            // nameWorkRemove
            // 
            this.nameWorkRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.nameWorkRemove.Location = new System.Drawing.Point(254, 110);
            this.nameWorkRemove.Name = "nameWorkRemove";
            this.nameWorkRemove.Size = new System.Drawing.Size(231, 27);
            this.nameWorkRemove.TabIndex = 64;
            // 
            // IDWorkRemove
            // 
            this.IDWorkRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.IDWorkRemove.Location = new System.Drawing.Point(254, 74);
            this.IDWorkRemove.Name = "IDWorkRemove";
            this.IDWorkRemove.Size = new System.Drawing.Size(231, 27);
            this.IDWorkRemove.TabIndex = 62;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(61, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(187, 40);
            this.label7.TabIndex = 63;
            this.label7.Text = "From which employee (Employees ID):";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label30.Location = new System.Drawing.Point(61, 77);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(187, 20);
            this.label30.TabIndex = 60;
            this.label30.Text = "ID of task to be removed:";
            // 
            // removeRecordButton
            // 
            this.removeRecordButton.AutoSize = true;
            this.removeRecordButton.BackColor = System.Drawing.SystemColors.Window;
            this.removeRecordButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.removeRecordButton.Location = new System.Drawing.Point(491, 108);
            this.removeRecordButton.Name = "removeRecordButton";
            this.removeRecordButton.Size = new System.Drawing.Size(33, 30);
            this.removeRecordButton.TabIndex = 61;
            this.removeRecordButton.Text = "▶";
            this.removeRecordButton.UseVisualStyleBackColor = false;
            this.removeRecordButton.Click += new System.EventHandler(this.removeRecordButton_Click_1);
            // 
            // updatePanelPlease
            // 
            this.updatePanelPlease.BackColor = System.Drawing.SystemColors.Window;
            this.updatePanelPlease.Controls.Add(this.label10);
            this.updatePanelPlease.Controls.Add(this.dateTimePicker2);
            this.updatePanelPlease.Controls.Add(this.button1);
            this.updatePanelPlease.Controls.Add(this.taskText2);
            this.updatePanelPlease.Controls.Add(this.label13);
            this.updatePanelPlease.Controls.Add(this.label8);
            this.updatePanelPlease.Controls.Add(this.taskIDText2);
            this.updatePanelPlease.Controls.Add(this.employeeIDText);
            this.updatePanelPlease.Controls.Add(this.label12);
            this.updatePanelPlease.Location = new System.Drawing.Point(149, 216);
            this.updatePanelPlease.Name = "updatePanelPlease";
            this.updatePanelPlease.Size = new System.Drawing.Size(588, 231);
            this.updatePanelPlease.TabIndex = 59;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Window;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.Location = new System.Drawing.Point(13, 187);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 20);
            this.label10.TabIndex = 68;
            this.label10.Text = "New Due Date:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dateTimePicker2.Location = new System.Drawing.Point(136, 187);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(337, 26);
            this.dateTimePicker2.TabIndex = 67;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.SystemColors.Window;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.Location = new System.Drawing.Point(479, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 30);
            this.button1.TabIndex = 66;
            this.button1.Text = "▶";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // taskText2
            // 
            this.taskText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskText2.Location = new System.Drawing.Point(136, 80);
            this.taskText2.Multiline = true;
            this.taskText2.Name = "taskText2";
            this.taskText2.Size = new System.Drawing.Size(376, 93);
            this.taskText2.TabIndex = 65;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.Window;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label13.Location = new System.Drawing.Point(13, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(211, 20);
            this.label13.TabIndex = 61;
            this.label13.Text = "Task to be updated (taskID):";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.Window;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(13, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 55);
            this.label8.TabIndex = 64;
            this.label8.Text = "New Task Description";
            // 
            // taskIDText2
            // 
            this.taskIDText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.taskIDText2.Location = new System.Drawing.Point(230, 9);
            this.taskIDText2.Name = "taskIDText2";
            this.taskIDText2.Size = new System.Drawing.Size(282, 27);
            this.taskIDText2.TabIndex = 60;
            // 
            // employeeIDText
            // 
            this.employeeIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.employeeIDText.Location = new System.Drawing.Point(230, 43);
            this.employeeIDText.Name = "employeeIDText";
            this.employeeIDText.Size = new System.Drawing.Size(282, 27);
            this.employeeIDText.TabIndex = 62;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.Window;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label12.Location = new System.Drawing.Point(13, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(208, 20);
            this.label12.TabIndex = 63;
            this.label12.Text = "For employee (employeeID):";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormSetWork
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EasyTask1.Properties.Resources._1754305_Website_Background_021;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.easyTaskAdminPanel);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.removeButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchNameButton);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.goBackButton);
            this.Controls.Add(this.removatePanel);
            this.Controls.Add(this.updatePanelPlease);
            this.Controls.Add(this.addPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormSetWork";
            this.Text = "FormSetWork";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.addPanel.ResumeLayout(false);
            this.addPanel.PerformLayout();
            this.removatePanel.ResumeLayout(false);
            this.removatePanel.PerformLayout();
            this.updatePanelPlease.ResumeLayout(false);
            this.updatePanelPlease.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button goBackButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button searchNameButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Panel addPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox employeeID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox taskID;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox taskDescription;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox setBy;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button addWorkButton;
        private System.Windows.Forms.Label easyTaskAdminPanel;
        private System.Windows.Forms.Panel removatePanel;
        private System.Windows.Forms.TextBox nameWorkRemove;
        private System.Windows.Forms.TextBox IDWorkRemove;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button removeRecordButton;
        private System.Windows.Forms.Panel updatePanelPlease;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox taskText2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox taskIDText2;
        private System.Windows.Forms.TextBox employeeIDText;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
    }
}