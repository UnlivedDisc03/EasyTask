﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EasyTask1
{
    public partial class EasyTaskWindow : Form
    {
        public static EasyTaskWindow instance;
        public EasyTaskWindow()
        {
            InitializeComponent();
            instance = this;
        }
        //initializes connection with my local host db
        SqlConnection connection = new SqlConnection("integrated security = true; data source=localhost;initial catalog=EasyTask");
        int attempts = 3; //set up login attempts 
        int timeLeft = 31; //sets up failure to login in 3 attempts waiting interval

        private void buttonUsername_Click(object sender, EventArgs e)//on login button click
        {
            connection.Open();
            string username = usernameTextBox.Text; //saves username from text box to a variable
            string userpassword = passTextBox.Text;//takes in the text found in the text boxes and saves it as the username and password


            try
            {
                //sets up the command to be sent to SQL Server
                string command = "SELECT * FROM LoginDetails WHERE username = '" + usernameTextBox.Text + "' AND password = '" + passTextBox.Text + "'";
                SqlDataAdapter getData = new SqlDataAdapter(command, connection);

                DataTable loginTable = new DataTable(); //creates a local table for the program to use and fills it with the data fetched from the sql server
                getData.Fill(loginTable);

                if (loginTable.Rows.Count > 0) //if a record of data has been fetched, it means both password and username matched that record exactly
                {//meaning the account with that combination exists.
                 
                    command = "SELECT e.adminStatus FROM Employees e INNER JOIN LoginDetails l ON e.employeeID = l.employeeID WHERE l.username = '" + usernameTextBox.Text + "' AND l.password = '" + passTextBox.Text + "'";//once we know it exists
                    SqlCommand cmd = new SqlCommand(command, connection);//the program then checks for the admin status of that account using an inner join to extract the adminstatus from employees and rest from LoginDetails
                    int isAdmin = (int)cmd.ExecuteScalar();//the query is executed and saved as result

                    if (isAdmin == 1)//if it is an admin
                    {
                        //object adminName = loginTable.Rows[0]["employeeName"];  beginigs for potential improvement, wanted to autoset the SetBy column name to whoever the logged on admin was.
                        //string currentAdmin = adminName.ToString();

                        Form2 Form2 = new Form2(); //initialize a variable as the 2nd form that the user will go to
                        Form2.Show();//shows the admin form
                        this.Hide();//hides this one
                        connection.Close(); //at the end close the connection
                    }
                    else if (isAdmin == 0)
                    {
                        Form3 Form3 = new Form3();//otherwise if not an admin, opens the regular employee sideof the program
                        Form3.instance.currentUser = usernameTextBox.Text; //transfers the current logged on user to form 3 so that it knows whos work/task data it should fetch.
                                                                           ////it does this by initialising an instance in form 3 beforehand aswell as a variable in form 3. This line of code sets that variable in form 3
                        Form3.Show();                                      //this exact piece of code is what can be used to compelte the above future imporement^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                        this.Hide();//hides this form
                        connection.Close(); //at the end close the connection
                    }
      
                }

                else
                {
                    if (usernameTextBox.Text == "" || passTextBox.Text == "")//checks if nothing was entered
                    {
                        MessageBox.Show("No username and/or password was entered, please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//messagebox shows nothing was enterd, attempts dont go down
                    }
                    else //otherwise if from before the table was emty, in other words no match was found for the entered combination of pass and user:
                    {
                        attempts = attempts - 1; //reduce attempts by 1
                        if (attempts == 0)//if attempts have reached zero
                        {
                            MessageBox.Show("You have exhausted all login attempts, please wait 30 seconds before trying again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//inform user no more attempts
                            buttonUsername.Enabled = false;//disable the option to login
                            timer1.Start();//start the 31 sec timer
                        }
                        else
                        {
                            MessageBox.Show("Invalid login details, remaining attempts: " + attempts, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//if user still has login attempts, they're prompted to try again
                            usernameTextBox.Clear();//clears the text boxrs
                            passTextBox.Clear(); 

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//any other potential error is returned
            }
            finally
            {
                connection.Close(); //at the end close the connection
            }
        }

        private void exitButton_Click(object sender, EventArgs e)//exit button
        {
            DialogResult  result;
            result = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)//if they click yes
            {
                connection.Close();//terminate connection and close app
                Application.Exit();
            }
            else
            {
                this.Show();//if no then just continue showing this form
            }
        }

        private void timer1_Tick(object sender, EventArgs e)//timer logic
        {
            timeLeft = timeLeft - 1;//on timer tick every 1000ms redcue seconds by 1
            buttonUsername.Text = timeLeft.ToString();//set the button text to be the time remaining till re activation

            if (timeLeft == 0)//if time is 0
            {
                timer1.Stop();//stop timer
                buttonUsername.Enabled = true;//reanable button and set its name back to true
                buttonUsername.Text = "Login";
                timeLeft = 31;//reset the timer and attempts
                attempts = 3;
            }
        }
    }
}
