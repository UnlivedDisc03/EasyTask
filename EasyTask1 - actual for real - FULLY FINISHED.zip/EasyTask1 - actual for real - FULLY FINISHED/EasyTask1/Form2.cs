﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyTask1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e) //BACK BUTTON
        {
            DialogResult result;
            result = MessageBox.Show("Are you sure you want to log-out?", "Log-out", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)//Goes back to the login page after displaying a confirmation pop uo
            {
                EasyTaskWindow Form1 = new EasyTaskWindow();
                Form1.Show();
                this.Hide();//back to form1
            }
            else
            {
                this.Show();//otheriwse if choice was dont logout stay on this form
            }

        }

        private void addUserButton_Click(object sender, EventArgs e)//manage emoployee button
        {
            FormManageEmployees Form4 = new FormManageEmployees();
            Form4.Show(); //takes you to manage employees form
            this.Hide();


        }

        private void setWorkButton_Click(object sender, EventArgs e)//manage employee work
        {
            FormSetWork FormSetWork = new FormSetWork();
            FormSetWork.Show();//closes this form and takes you
            this.Hide();
        }

        private void statisticsButton_Click(object sender, EventArgs e)//employee statistics form
        {
            EmployeeStatisticsForm EmployeeStatisticsForm = new EmployeeStatisticsForm();//open data analysis window close this one
            EmployeeStatisticsForm.Show();
            this.Hide();
        }

        private void reviewWorkButton_Click(object sender, EventArgs e)//review work button
        {
            FormReviewWork FormReviewWork = new FormReviewWork();//open review work form close this one
            FormReviewWork.Show();
            this.Hide();
        }
    }
}
