﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EasyTask1
{
    public partial class Form3 : Form
    {
        public static Form3 instance; //sets up this form as a global instance which allows me to reference it in form 1
        public string currentUser;//sets up the variable that data is saved to from form1 specifically the username of the currently logged in user. Its what allows me to bring up the tasks specific to the logged on  employee
        public Form3()
        {
            InitializeComponent();
            instance = this;//sets instance to be this form
            panelWorkReview.Visible = false;//makes sure on start nothing is shown just the main screen
        }

        string connectionString = "integrated security = true; data source=localhost;initial catalog=EasyTask";

        private void refreshButton_Click(object sender, EventArgs e) //VIEW ALL TASKS BUTTON
        {
            using (SqlConnection connection = new SqlConnection(connectionString))//establish connection tht auto closes
            {
                connection.Open();
                try
                {
                    string command = "SELECT w.taskID, w.employeeID, e.employeeName, w.taskDescription, w.dateSet, w.dateDue, w.workComplete, w.workReview AS employeeComment, w.performanceScore, w.punctuality AS punctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID INNER JOIN LoginDetails l ON l.employeeID = w.employeeID WHERE l.username = '" + currentUser + "' ORDER BY dateDue DESC";
                    //on viewnall taks button click, shows relevant information regardin the users task where the current user is the variable we set from for 1 containing the user name frm table loginDetails inner joined with Employees and WorkSet on employeeID
                    SqlDataAdapter sqlda = new SqlDataAdapter(command, connection);//displays every task
                    DataTable allEmployeesTable = new DataTable();
                    sqlda.Fill(allEmployeesTable);//fills a table with the result of the query

                    dataGridView1.DataSource = allEmployeesTable;//said table is displayed on the datagridview
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//if an errro occurs it displays it in a messsage box
                }
            }
        }

        private void goBackButton_Click(object sender, EventArgs e) //button at top right of the screen
        {
            DialogResult result;
            result = MessageBox.Show("Are you sure you want to log-out?", "Log-out", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)//brings them back to the login page after asking if they want top logout of not
            {
                EasyTaskWindow Form1 = new EasyTaskWindow();
                Form1.Show();
                this.Hide();//if yes go back to form1
            }
            else
            {//oterhwise do nothing
                this.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e) //UPCOMING TASKS BUTTON
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    DateTime currentDate = DateTime.Now.Date;//check crrent date
                    string command = "SELECT w.taskID, w.employeeID, e.employeeName, w.taskDescription, w.dateSet, w.dateDue, w.workComplete, w.workReview AS employeeComment, w.performanceScore, w.punctuality AS punctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID INNER JOIN LoginDetails l ON l.employeeID = w.employeeID WHERE l.username = '" + currentUser + "' AND w.dateDue >= @currentDate AND w.workComplete != 'YES' ORDER BY dateDue ASC";
                    //select relevant columns where work is not completed and the due date is later than todays current date. In order to do this I inner joined 3 tables together to extract columns from employees and worSet tables and then used the username from loginDetails as the condition 
                    using (SqlCommand cmd = new SqlCommand(command, connection))
                    {
                        cmd.Parameters.AddWithValue("@currentDate", currentDate);//Using currentDate by itself didn't work apparently due to the time being present on the date at 00:00:00
                        //by replacing the @currentDate within the query with this line of code it bypasses that error and works perfectly.

                        using (SqlDataAdapter sqlda = new SqlDataAdapter(cmd))
                        {
                            DataTable allEmployeesTable = new DataTable();
                            sqlda.Fill(allEmployeesTable);

                            dataGridView1.DataSource = allEmployeesTable;//fill the datagrid with the fetched results of upcoming tasks
                        }
                    }
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//if an error occurs show the error message
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) //VIEW PAST TASKS
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();//establishes an auto closing connection
                try
                {
                    DateTime currentDate = DateTime.Now.Date;
                    string command = "SELECT w.taskID, w.employeeID, e.employeeName, w.taskDescription, w.dateSet, w.dateDue, w.workComplete, w.workReview AS employeeComment, w.performanceScore, w.punctuality AS punctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID INNER JOIN LoginDetails l ON l.employeeID = w.employeeID WHERE l.username = '" + currentUser + "' AND (w.dateDue < @currentDate OR w.workComplete = 'YES') ORDER BY dateDue DESC";
                    //select relevant columns that are less than todays current date or where work has been completed. View past and completed tasks starting from most recent one
                    //this select also uses data from 3 different tables due to my oversight of not adding the employee name.
                    using (SqlCommand cmd = new SqlCommand(command, connection))
                    {
                        cmd.Parameters.AddWithValue("@currentDate", currentDate);

                        using (SqlDataAdapter sqlda = new SqlDataAdapter(cmd))
                        {
                            DataTable allEmployeesTable = new DataTable();
                            sqlda.Fill(allEmployeesTable);

                            dataGridView1.DataSource = allEmployeesTable;//shows results on datagrid of all past tasks that are less than todays date
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//shows any errors
                }
            }
        }

        private void button3_Click(object sender, EventArgs e) //bring up submit work panel
        {
            panelWorkReview.Visible = true;//show the panel to submit a user comment
        }

        private void button6_Click(object sender, EventArgs e) //hide work review panel
        {
            workReviewText.Clear();//hides the panel and clears any text that was in it
            panelWorkReview.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))//ACTUAL BUTTONT HAT SUBMITS THE WORK UNDER THE workReviewPanel
            {
                connection.Open();
                try
                {
                    string command = "SELECT DATEDIFF(DAY, GETDATE(), dateDue) AS punctuality FROM WorkSet WHERE taskID = " + workTaskID.Text;//gets the difference in dates
                    //textBox1test.Text = command; used for previous testing
                    SqlCommand cmd = new SqlCommand(command, connection);
                    object punctualityObject = cmd.ExecuteScalar();
                    int punctuality = Convert.ToInt32(punctualityObject);//saves it as a number of punctuality. Determines how many dates ahead the user submitted the work as finished. Higher punct = better

                    command = "UPDATE WorkSet SET workReview = '" + workReviewText.Text + "', workComplete = 'YES', punctuality = " + punctuality + " WHERE employeeID = (SELECT employeeID FROM loginDetails WHERE username = '" + currentUser + "' AND taskID = " + workTaskID.Text + ")";
                    //uses an inner query to access login table so that username can be used here when it isnt a part of the WorkSet table.
                    //updates work set with the workreview, changes workComplete to yes and sets the punctuality for that user and that specific task
                    //textBox1test.Text = command; this was used to see f the command was written correctly. When writing such a long query its very common for me to make simple unspotable spelling mistakes until i see them during program runtime.
                    cmd = new SqlCommand(command, connection);
                    cmd.ExecuteNonQuery();

                    panelWorkReview.Visible = false;//panel auto closes after a work is submitted

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}, Ensure no apostrophes are used as they interfere with database operations.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //I realised during my testing that the program cannot handle apostrophes as it messess up the operations of the sql queries. for example "set workReview = 'sample text I'm doing ok'" ends the value to be set into column workReview at I'm. everything beyonf that ' errors. 
                    ///////////I decided to include this in the program but in a real scenario the text would be taken and processed to remove any appostrophes before passing it to the select statement.
                }
            }

            //workReviewText.Clear();
        }
    }
}
