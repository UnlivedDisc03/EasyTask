﻿
namespace EasyTask1
{
    partial class FormManageEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.goBackButton = new System.Windows.Forms.Button();
            this.easyTaskAdminPanel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshButton = new System.Windows.Forms.Button();
            this.userInputTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.searchByCombo = new System.Windows.Forms.ComboBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.sortByCombo = new System.Windows.Forms.ComboBox();
            this.addPanel = new System.Windows.Forms.Panel();
            this.confirmAddButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.adminCombo = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.depTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.PNTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.IDTextBox = new System.Windows.Forms.TextBox();
            this.addButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.emptyPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.updatePanel = new System.Windows.Forms.Panel();
            this.updateByValue = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.updateByCombo = new System.Windows.Forms.ComboBox();
            this.updateRecordButton = new System.Windows.Forms.Button();
            this.upSalary = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.upDate = new System.Windows.Forms.DateTimePicker();
            this.upAdmin = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.upDep = new System.Windows.Forms.TextBox();
            this.upEmail = new System.Windows.Forms.TextBox();
            this.upPN = new System.Windows.Forms.TextBox();
            this.upName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.upID = new System.Windows.Forms.TextBox();
            this.removePanel = new System.Windows.Forms.Panel();
            this.removeByvalue = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.removeByCombo = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.removeRecordButton = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.addPanel.SuspendLayout();
            this.updatePanel.SuspendLayout();
            this.removePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // goBackButton
            // 
            this.goBackButton.AutoSize = true;
            this.goBackButton.BackColor = System.Drawing.SystemColors.Window;
            this.goBackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.goBackButton.Location = new System.Drawing.Point(56, 18);
            this.goBackButton.Name = "goBackButton";
            this.goBackButton.Size = new System.Drawing.Size(33, 30);
            this.goBackButton.TabIndex = 10;
            this.goBackButton.Text = "◀ ";
            this.goBackButton.UseVisualStyleBackColor = false;
            this.goBackButton.Click += new System.EventHandler(this.goBackButton_Click);
            // 
            // easyTaskAdminPanel
            // 
            this.easyTaskAdminPanel.AutoSize = true;
            this.easyTaskAdminPanel.BackColor = System.Drawing.SystemColors.Window;
            this.easyTaskAdminPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easyTaskAdminPanel.Location = new System.Drawing.Point(116, 9);
            this.easyTaskAdminPanel.Name = "easyTaskAdminPanel";
            this.easyTaskAdminPanel.Size = new System.Drawing.Size(603, 39);
            this.easyTaskAdminPanel.TabIndex = 11;
            this.easyTaskAdminPanel.Text = "EasyTask Admin - Manage Employees";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(58, 66);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(687, 117);
            this.dataGridView1.TabIndex = 12;
            // 
            // refreshButton
            // 
            this.refreshButton.AutoSize = true;
            this.refreshButton.BackColor = System.Drawing.SystemColors.Window;
            this.refreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.refreshButton.Location = new System.Drawing.Point(669, 187);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(76, 30);
            this.refreshButton.TabIndex = 13;
            this.refreshButton.Text = "Refresh";
            this.refreshButton.UseVisualStyleBackColor = false;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // userInputTextBox
            // 
            this.userInputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.userInputTextBox.Location = new System.Drawing.Point(307, 189);
            this.userInputTextBox.Name = "userInputTextBox";
            this.userInputTextBox.Size = new System.Drawing.Size(277, 27);
            this.userInputTextBox.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(54, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 15;
            // 
            // searchByCombo
            // 
            this.searchByCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.searchByCombo.FormattingEnabled = true;
            this.searchByCombo.Items.AddRange(new object[] {
            "employeeID",
            "employeeName",
            "employeePhoneNumber",
            "employeeEmail",
            "department",
            "dateOfBirth",
            "adminStatus",
            "yearlySalary"});
            this.searchByCombo.Location = new System.Drawing.Point(56, 189);
            this.searchByCombo.Name = "searchByCombo";
            this.searchByCombo.Size = new System.Drawing.Size(121, 28);
            this.searchByCombo.TabIndex = 16;
            this.searchByCombo.Text = "Search by:";
            // 
            // searchButton
            // 
            this.searchButton.AutoSize = true;
            this.searchButton.BackColor = System.Drawing.SystemColors.Window;
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.searchButton.Location = new System.Drawing.Point(590, 187);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(76, 30);
            this.searchButton.TabIndex = 17;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = false;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // sortByCombo
            // 
            this.sortByCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.sortByCombo.FormattingEnabled = true;
            this.sortByCombo.Items.AddRange(new object[] {
            "employeeID",
            "employeeName",
            "employeePhoneNumber",
            "employeeEmail",
            "department",
            "dateOfBirth",
            "adminStatus",
            "yearlySalary"});
            this.sortByCombo.Location = new System.Drawing.Point(183, 189);
            this.sortByCombo.Name = "sortByCombo";
            this.sortByCombo.Size = new System.Drawing.Size(121, 28);
            this.sortByCombo.TabIndex = 18;
            this.sortByCombo.Text = "Sort By:";
            this.sortByCombo.SelectedIndexChanged += new System.EventHandler(this.sortByCombo_SelectedIndexChanged);
            // 
            // addPanel
            // 
            this.addPanel.BackColor = System.Drawing.SystemColors.Window;
            this.addPanel.Controls.Add(this.confirmAddButton);
            this.addPanel.Controls.Add(this.clearButton);
            this.addPanel.Controls.Add(this.salaryTextBox);
            this.addPanel.Controls.Add(this.label10);
            this.addPanel.Controls.Add(this.dateTimePicker1);
            this.addPanel.Controls.Add(this.adminCombo);
            this.addPanel.Controls.Add(this.label8);
            this.addPanel.Controls.Add(this.label7);
            this.addPanel.Controls.Add(this.depTextBox);
            this.addPanel.Controls.Add(this.emailTextBox);
            this.addPanel.Controls.Add(this.PNTextBox);
            this.addPanel.Controls.Add(this.nameTextBox);
            this.addPanel.Controls.Add(this.label6);
            this.addPanel.Controls.Add(this.label5);
            this.addPanel.Controls.Add(this.label4);
            this.addPanel.Controls.Add(this.label3);
            this.addPanel.Controls.Add(this.label2);
            this.addPanel.Controls.Add(this.IDTextBox);
            this.addPanel.Location = new System.Drawing.Point(158, 238);
            this.addPanel.Name = "addPanel";
            this.addPanel.Size = new System.Drawing.Size(573, 200);
            this.addPanel.TabIndex = 19;
            // 
            // confirmAddButton
            // 
            this.confirmAddButton.AutoSize = true;
            this.confirmAddButton.BackColor = System.Drawing.SystemColors.Window;
            this.confirmAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.confirmAddButton.Location = new System.Drawing.Point(508, 159);
            this.confirmAddButton.Name = "confirmAddButton";
            this.confirmAddButton.Size = new System.Drawing.Size(33, 30);
            this.confirmAddButton.TabIndex = 38;
            this.confirmAddButton.Text = "▶";
            this.confirmAddButton.UseVisualStyleBackColor = false;
            this.confirmAddButton.Click += new System.EventHandler(this.confirmAddButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.AutoSize = true;
            this.clearButton.BackColor = System.Drawing.SystemColors.Window;
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.clearButton.Location = new System.Drawing.Point(380, 159);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(122, 30);
            this.clearButton.TabIndex = 38;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = false;
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.salaryTextBox.Location = new System.Drawing.Point(380, 87);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(161, 27);
            this.salaryTextBox.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.Location = new System.Drawing.Point(288, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 20);
            this.label10.TabIndex = 37;
            this.label10.Text = "Salary:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dateTimePicker1.Location = new System.Drawing.Point(380, 15);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(161, 26);
            this.dateTimePicker1.TabIndex = 36;
            // 
            // adminCombo
            // 
            this.adminCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.adminCombo.FormattingEnabled = true;
            this.adminCombo.Items.AddRange(new object[] {
            "0",
            "1"});
            this.adminCombo.Location = new System.Drawing.Point(380, 49);
            this.adminCombo.Name = "adminCombo";
            this.adminCombo.Size = new System.Drawing.Size(161, 28);
            this.adminCombo.TabIndex = 23;
            this.adminCombo.Text = "0 for no, 1 for yes";
            this.adminCombo.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(288, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "Admin:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(288, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Birth Date:";
            // 
            // depTextBox
            // 
            this.depTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.depTextBox.Location = new System.Drawing.Point(124, 159);
            this.depTextBox.Name = "depTextBox";
            this.depTextBox.Size = new System.Drawing.Size(144, 27);
            this.depTextBox.TabIndex = 32;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.emailTextBox.Location = new System.Drawing.Point(124, 120);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(144, 27);
            this.emailTextBox.TabIndex = 31;
            // 
            // PNTextBox
            // 
            this.PNTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.PNTextBox.Location = new System.Drawing.Point(124, 84);
            this.PNTextBox.Name = "PNTextBox";
            this.PNTextBox.Size = new System.Drawing.Size(144, 27);
            this.PNTextBox.TabIndex = 30;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.nameTextBox.Location = new System.Drawing.Point(124, 48);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(144, 27);
            this.nameTextBox.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(3, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 20);
            this.label6.TabIndex = 28;
            this.label6.Text = "Department:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(3, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 27;
            this.label5.Text = "Email:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(3, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 20);
            this.label4.TabIndex = 26;
            this.label4.Text = "PhoneNumber:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(3, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(3, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 20);
            this.label2.TabIndex = 24;
            this.label2.Text = "ID:";
            // 
            // IDTextBox
            // 
            this.IDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.IDTextBox.Location = new System.Drawing.Point(124, 12);
            this.IDTextBox.Name = "IDTextBox";
            this.IDTextBox.Size = new System.Drawing.Size(144, 27);
            this.IDTextBox.TabIndex = 23;
            // 
            // addButton
            // 
            this.addButton.AutoSize = true;
            this.addButton.BackColor = System.Drawing.SystemColors.Window;
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.addButton.Location = new System.Drawing.Point(52, 285);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(88, 30);
            this.addButton.TabIndex = 20;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.AutoSize = true;
            this.removeButton.BackColor = System.Drawing.SystemColors.Window;
            this.removeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.removeButton.Location = new System.Drawing.Point(54, 321);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(86, 30);
            this.removeButton.TabIndex = 21;
            this.removeButton.Text = "Remove";
            this.removeButton.UseVisualStyleBackColor = false;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.AutoSize = true;
            this.updateButton.BackColor = System.Drawing.SystemColors.Window;
            this.updateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.updateButton.Location = new System.Drawing.Point(54, 357);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(86, 30);
            this.updateButton.TabIndex = 22;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.Window;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(52, 238);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 41);
            this.label9.TabIndex = 37;
            this.label9.Text = "Manage Employees";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // emptyPanel
            // 
            this.emptyPanel.BackColor = System.Drawing.SystemColors.Window;
            this.emptyPanel.Location = new System.Drawing.Point(158, 238);
            this.emptyPanel.Name = "emptyPanel";
            this.emptyPanel.Size = new System.Drawing.Size(573, 200);
            this.emptyPanel.TabIndex = 40;
            // 
            // updatePanel
            // 
            this.updatePanel.BackColor = System.Drawing.SystemColors.Window;
            this.updatePanel.Controls.Add(this.updateByValue);
            this.updatePanel.Controls.Add(this.label20);
            this.updatePanel.Controls.Add(this.label19);
            this.updatePanel.Controls.Add(this.updateByCombo);
            this.updatePanel.Controls.Add(this.updateRecordButton);
            this.updatePanel.Controls.Add(this.upSalary);
            this.updatePanel.Controls.Add(this.label11);
            this.updatePanel.Controls.Add(this.upDate);
            this.updatePanel.Controls.Add(this.upAdmin);
            this.updatePanel.Controls.Add(this.label12);
            this.updatePanel.Controls.Add(this.label13);
            this.updatePanel.Controls.Add(this.upDep);
            this.updatePanel.Controls.Add(this.upEmail);
            this.updatePanel.Controls.Add(this.upPN);
            this.updatePanel.Controls.Add(this.upName);
            this.updatePanel.Controls.Add(this.label14);
            this.updatePanel.Controls.Add(this.label15);
            this.updatePanel.Controls.Add(this.label16);
            this.updatePanel.Controls.Add(this.label17);
            this.updatePanel.Controls.Add(this.label18);
            this.updatePanel.Controls.Add(this.upID);
            this.updatePanel.Location = new System.Drawing.Point(158, 238);
            this.updatePanel.Name = "updatePanel";
            this.updatePanel.Size = new System.Drawing.Size(573, 200);
            this.updatePanel.TabIndex = 41;
            // 
            // updateByValue
            // 
            this.updateByValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.updateByValue.Location = new System.Drawing.Point(325, 161);
            this.updateByValue.Name = "updateByValue";
            this.updateByValue.Size = new System.Drawing.Size(177, 27);
            this.updateByValue.TabIndex = 42;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label20.Location = new System.Drawing.Point(301, 164);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(18, 20);
            this.label20.TabIndex = 41;
            this.label20.Text = "=";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label19.Location = new System.Drawing.Point(3, 164);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 20);
            this.label19.TabIndex = 40;
            this.label19.Text = "Update record where";
            // 
            // updateByCombo
            // 
            this.updateByCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.updateByCombo.FormattingEnabled = true;
            this.updateByCombo.Items.AddRange(new object[] {
            "employeeID",
            "employeeName",
            "employeePhoneNumber",
            "employeeEmail",
            "department",
            "dateOfBirth",
            "adminStatus",
            "yearlySalary"});
            this.updateByCombo.Location = new System.Drawing.Point(167, 161);
            this.updateByCombo.Name = "updateByCombo";
            this.updateByCombo.Size = new System.Drawing.Size(128, 28);
            this.updateByCombo.TabIndex = 39;
            this.updateByCombo.Text = "Update By:";
            // 
            // updateRecordButton
            // 
            this.updateRecordButton.AutoSize = true;
            this.updateRecordButton.BackColor = System.Drawing.SystemColors.Window;
            this.updateRecordButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.updateRecordButton.Location = new System.Drawing.Point(508, 159);
            this.updateRecordButton.Name = "updateRecordButton";
            this.updateRecordButton.Size = new System.Drawing.Size(33, 30);
            this.updateRecordButton.TabIndex = 38;
            this.updateRecordButton.Text = "▶";
            this.updateRecordButton.UseVisualStyleBackColor = false;
            this.updateRecordButton.Click += new System.EventHandler(this.updateRecordButton_Click);
            // 
            // upSalary
            // 
            this.upSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.upSalary.Location = new System.Drawing.Point(380, 113);
            this.upSalary.Name = "upSalary";
            this.upSalary.Size = new System.Drawing.Size(161, 27);
            this.upSalary.TabIndex = 38;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label11.Location = new System.Drawing.Point(274, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 20);
            this.label11.TabIndex = 37;
            this.label11.Text = "Salary:";
            // 
            // upDate
            // 
            this.upDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.upDate.Location = new System.Drawing.Point(380, 45);
            this.upDate.Name = "upDate";
            this.upDate.Size = new System.Drawing.Size(161, 26);
            this.upDate.TabIndex = 36;
            // 
            // upAdmin
            // 
            this.upAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.upAdmin.FormattingEnabled = true;
            this.upAdmin.Items.AddRange(new object[] {
            "0",
            "1"});
            this.upAdmin.Location = new System.Drawing.Point(380, 79);
            this.upAdmin.Name = "upAdmin";
            this.upAdmin.Size = new System.Drawing.Size(161, 28);
            this.upAdmin.TabIndex = 23;
            this.upAdmin.Text = "0 for no, 1 for yes";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label12.Location = new System.Drawing.Point(274, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 20);
            this.label12.TabIndex = 35;
            this.label12.Text = "Admin:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label13.Location = new System.Drawing.Point(274, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 20);
            this.label13.TabIndex = 33;
            this.label13.Text = "Birth Date:";
            // 
            // upDep
            // 
            this.upDep.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.upDep.Location = new System.Drawing.Point(380, 10);
            this.upDep.Name = "upDep";
            this.upDep.Size = new System.Drawing.Size(161, 27);
            this.upDep.TabIndex = 32;
            // 
            // upEmail
            // 
            this.upEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.upEmail.Location = new System.Drawing.Point(124, 120);
            this.upEmail.Name = "upEmail";
            this.upEmail.Size = new System.Drawing.Size(144, 27);
            this.upEmail.TabIndex = 31;
            // 
            // upPN
            // 
            this.upPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.upPN.Location = new System.Drawing.Point(124, 84);
            this.upPN.Name = "upPN";
            this.upPN.Size = new System.Drawing.Size(144, 27);
            this.upPN.TabIndex = 30;
            // 
            // upName
            // 
            this.upName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.upName.Location = new System.Drawing.Point(124, 48);
            this.upName.Name = "upName";
            this.upName.Size = new System.Drawing.Size(144, 27);
            this.upName.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label14.Location = new System.Drawing.Point(274, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 20);
            this.label14.TabIndex = 28;
            this.label14.Text = "Department:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label15.Location = new System.Drawing.Point(3, 123);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 20);
            this.label15.TabIndex = 27;
            this.label15.Text = "Email:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label16.Location = new System.Drawing.Point(3, 87);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(115, 20);
            this.label16.TabIndex = 26;
            this.label16.Text = "PhoneNumber:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label17.Location = new System.Drawing.Point(3, 51);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 20);
            this.label17.TabIndex = 25;
            this.label17.Text = "Name:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label18.Location = new System.Drawing.Point(3, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 20);
            this.label18.TabIndex = 24;
            this.label18.Text = "ID:";
            // 
            // upID
            // 
            this.upID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.upID.Location = new System.Drawing.Point(124, 12);
            this.upID.Name = "upID";
            this.upID.Size = new System.Drawing.Size(144, 27);
            this.upID.TabIndex = 23;
            // 
            // removePanel
            // 
            this.removePanel.BackColor = System.Drawing.SystemColors.Window;
            this.removePanel.Controls.Add(this.removeByvalue);
            this.removePanel.Controls.Add(this.label23);
            this.removePanel.Controls.Add(this.removeByCombo);
            this.removePanel.Controls.Add(this.label22);
            this.removePanel.Controls.Add(this.removeRecordButton);
            this.removePanel.Controls.Add(this.label30);
            this.removePanel.Location = new System.Drawing.Point(158, 238);
            this.removePanel.Name = "removePanel";
            this.removePanel.Size = new System.Drawing.Size(573, 200);
            this.removePanel.TabIndex = 42;
            // 
            // removeByvalue
            // 
            this.removeByvalue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.removeByvalue.Location = new System.Drawing.Point(409, 49);
            this.removeByvalue.Name = "removeByvalue";
            this.removeByvalue.Size = new System.Drawing.Size(122, 27);
            this.removeByvalue.TabIndex = 45;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label23.Location = new System.Drawing.Point(321, 53);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(87, 20);
            this.label23.TabIndex = 44;
            this.label23.Text = "Is equal to:";
            // 
            // removeByCombo
            // 
            this.removeByCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.removeByCombo.FormattingEnabled = true;
            this.removeByCombo.Items.AddRange(new object[] {
            "employeeID",
            "employeeName",
            "employeePhoneNumber",
            "employeeEmail",
            "department",
            "dateOfBirth",
            "adminStatus",
            "yearlySalary"});
            this.removeByCombo.Location = new System.Drawing.Point(191, 50);
            this.removeByCombo.Name = "removeByCombo";
            this.removeByCombo.Size = new System.Drawing.Size(128, 28);
            this.removeByCombo.TabIndex = 43;
            this.removeByCombo.Text = "Select a value:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label22.Location = new System.Drawing.Point(3, 164);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 20);
            this.label22.TabIndex = 40;
            // 
            // removeRecordButton
            // 
            this.removeRecordButton.AutoSize = true;
            this.removeRecordButton.BackColor = System.Drawing.SystemColors.Window;
            this.removeRecordButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.removeRecordButton.Location = new System.Drawing.Point(537, 48);
            this.removeRecordButton.Name = "removeRecordButton";
            this.removeRecordButton.Size = new System.Drawing.Size(33, 30);
            this.removeRecordButton.TabIndex = 38;
            this.removeRecordButton.Text = "▶";
            this.removeRecordButton.UseVisualStyleBackColor = false;
            this.removeRecordButton.Click += new System.EventHandler(this.removeRecordButton_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label30.Location = new System.Drawing.Point(3, 52);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(191, 20);
            this.label30.TabIndex = 24;
            this.label30.Text = "Remove employee where:";
            // 
            // FormManageEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EasyTask1.Properties.Resources._1754305_Website_Background_021;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.removeButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.sortByCombo);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.searchByCombo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.userInputTextBox);
            this.Controls.Add(this.refreshButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.easyTaskAdminPanel);
            this.Controls.Add(this.goBackButton);
            this.Controls.Add(this.removePanel);
            this.Controls.Add(this.updatePanel);
            this.Controls.Add(this.emptyPanel);
            this.Controls.Add(this.addPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormManageEmployees";
            this.Text = "FormManageEmployees";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.addPanel.ResumeLayout(false);
            this.addPanel.PerformLayout();
            this.updatePanel.ResumeLayout(false);
            this.updatePanel.PerformLayout();
            this.removePanel.ResumeLayout(false);
            this.removePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button goBackButton;
        private System.Windows.Forms.Label easyTaskAdminPanel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.TextBox userInputTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox searchByCombo;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.ComboBox sortByCombo;
        private System.Windows.Forms.Panel addPanel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox adminCombo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox depTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox PNTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox IDTextBox;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button confirmAddButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.FlowLayoutPanel emptyPanel;
        private System.Windows.Forms.Panel updatePanel;
        private System.Windows.Forms.TextBox updateByValue;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox updateByCombo;
        private System.Windows.Forms.Button updateRecordButton;
        private System.Windows.Forms.TextBox upSalary;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker upDate;
        private System.Windows.Forms.ComboBox upAdmin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox upDep;
        private System.Windows.Forms.TextBox upEmail;
        private System.Windows.Forms.TextBox upPN;
        private System.Windows.Forms.TextBox upName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox upID;
        private System.Windows.Forms.Panel removePanel;
        private System.Windows.Forms.TextBox removeByvalue;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox removeByCombo;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button removeRecordButton;
        private System.Windows.Forms.Label label30;
    }
}