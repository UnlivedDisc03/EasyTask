﻿
namespace EasyTask1
{
    partial class EmployeeStatisticsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.easyTaskAdminPanel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.goBackButton = new System.Windows.Forms.Button();
            this.punctualityButton = new System.Windows.Forms.Button();
            this.performanceButton = new System.Windows.Forms.Button();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.checkByUser = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // easyTaskAdminPanel
            // 
            this.easyTaskAdminPanel.AutoSize = true;
            this.easyTaskAdminPanel.BackColor = System.Drawing.SystemColors.Window;
            this.easyTaskAdminPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easyTaskAdminPanel.Location = new System.Drawing.Point(105, 6);
            this.easyTaskAdminPanel.Name = "easyTaskAdminPanel";
            this.easyTaskAdminPanel.Size = new System.Drawing.Size(599, 39);
            this.easyTaskAdminPanel.TabIndex = 62;
            this.easyTaskAdminPanel.Text = "EasyTask Admin - Employee Statistics";
            this.easyTaskAdminPanel.Click += new System.EventHandler(this.easyTaskAdminPanel_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(56, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(687, 236);
            this.dataGridView1.TabIndex = 61;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // goBackButton
            // 
            this.goBackButton.AutoSize = true;
            this.goBackButton.BackColor = System.Drawing.SystemColors.Window;
            this.goBackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.goBackButton.Location = new System.Drawing.Point(56, 16);
            this.goBackButton.Name = "goBackButton";
            this.goBackButton.Size = new System.Drawing.Size(33, 30);
            this.goBackButton.TabIndex = 60;
            this.goBackButton.Text = "◀ ";
            this.goBackButton.UseVisualStyleBackColor = false;
            this.goBackButton.Click += new System.EventHandler(this.goBackButton_Click);
            // 
            // punctualityButton
            // 
            this.punctualityButton.AutoSize = true;
            this.punctualityButton.BackColor = System.Drawing.SystemColors.Window;
            this.punctualityButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.punctualityButton.Location = new System.Drawing.Point(56, 328);
            this.punctualityButton.Name = "punctualityButton";
            this.punctualityButton.Size = new System.Drawing.Size(159, 30);
            this.punctualityButton.TabIndex = 63;
            this.punctualityButton.Text = "Check Punctuality";
            this.punctualityButton.UseVisualStyleBackColor = false;
            this.punctualityButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // performanceButton
            // 
            this.performanceButton.AutoSize = true;
            this.performanceButton.BackColor = System.Drawing.SystemColors.Window;
            this.performanceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.performanceButton.Location = new System.Drawing.Point(56, 367);
            this.performanceButton.Name = "performanceButton";
            this.performanceButton.Size = new System.Drawing.Size(159, 30);
            this.performanceButton.TabIndex = 64;
            this.performanceButton.Text = "Check Performance";
            this.performanceButton.UseVisualStyleBackColor = false;
            this.performanceButton.Click += new System.EventHandler(this.performanceButton_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.nameTextBox.Location = new System.Drawing.Point(436, 297);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(227, 27);
            this.nameTextBox.TabIndex = 65;
            this.nameTextBox.TextChanged += new System.EventHandler(this.nameTextBox_TextChanged);
            // 
            // checkByUser
            // 
            this.checkByUser.AutoSize = true;
            this.checkByUser.BackColor = System.Drawing.SystemColors.Window;
            this.checkByUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.checkByUser.Location = new System.Drawing.Point(669, 295);
            this.checkByUser.Name = "checkByUser";
            this.checkByUser.Size = new System.Drawing.Size(74, 30);
            this.checkByUser.TabIndex = 66;
            this.checkByUser.Text = "Search";
            this.checkByUser.UseVisualStyleBackColor = false;
            this.checkByUser.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Location = new System.Drawing.Point(221, 327);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(529, 56);
            this.label1.TabIndex = 67;
            this.label1.Text = "- Compare the punctuality (how many days did the user submit their work ahead of " +
    "the deadline) of work submition between employees";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Window;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label2.Location = new System.Drawing.Point(221, 372);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(529, 20);
            this.label2.TabIndex = 68;
            this.label2.Text = "- Compare the performance scores of submitted work between employees";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Window;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(52, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(378, 20);
            this.label9.TabIndex = 69;
            this.label9.Text = "Employees name of who\'s work you wish to manage:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EmployeeStatisticsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EasyTask1.Properties.Resources._1754305_Website_Background_021;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkByUser);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.performanceButton);
            this.Controls.Add(this.punctualityButton);
            this.Controls.Add(this.easyTaskAdminPanel);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.goBackButton);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EmployeeStatisticsForm";
            this.Text = "EmployeeStatisticsForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label easyTaskAdminPanel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button goBackButton;
        private System.Windows.Forms.Button punctualityButton;
        private System.Windows.Forms.Button performanceButton;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button checkByUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
    }
}