﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EasyTask1
{
    public partial class EmployeeStatisticsForm : Form
    {
        public EmployeeStatisticsForm()
        {
            InitializeComponent();
        }

        string connectionString = "integrated security = true; data source=localhost;initial catalog=EasyTask";

        private void goBackButton_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();
            Form2.Show();//go back to admin menu
            this.Hide();
        }

        private void addButton_Click(object sender, EventArgs e)//punctuality button
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    string command = "SELECT w.employeeID, e.employeeName, AVG(w.punctuality) as averagePunctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID GROUP BY w.employeeID, e.employeeName ORDER BY averagePunctuality DESC";
                    //selects relevant employee infrmation and most importantly the average punctuality between all tasks. Groups the results by the employee id and name and orders the results with highest punctuality (days submitted in advance) at the top.
                    //userInputTextBox.Text = command;
                    SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);//sets the adaptor command
                    DataTable queriedEmployees = new DataTable(); //creates a table in vscode
                    sqlda2.Fill(queriedEmployees);//filss said table using the sqldataadaptor command

                    dataGridView1.DataSource = queriedEmployees;//sets the grid view to be the table
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//shows any potential errors
                }
            }
        }




        private void button2_Click(object sender, EventArgs e)//search by name button
        {
            string userInput = nameTextBox.Text.ToString(); //takes in the name from the text box

            using (SqlConnection connection = new SqlConnection(connectionString))//establishes auto closing connection
            {
                connection.Open();
                try
                {
                    if (userInput == "")//if notging was entered tells the user to enter a specific users name
                    {
                        MessageBox.Show("Nothing was entered to be queried, Please make sure you select a search category and enter an appropriate value to be queried.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string command = "SELECT w.employeeID, e.employeeName, AVG(w.performanceScore) AS averagePerformanceScore, AVG(w.punctuality) as averagePunctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID WHERE e.employeeName = '" + userInput + "' GROUP BY w.employeeID, e.employeeName";
                        //selects relevant info from relevant tables including the average performance score grouped by the empID and name where employee is whatever they searched for.
                        //userInputTextBox.Text = command;
                        SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);
                        DataTable queriedEmployees = new DataTable();
                        sqlda2.Fill(queriedEmployees);

                        dataGridView1.DataSource = queriedEmployees;//shows results in the data grid view
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//shows potential errors
                }
            }
        }

        private void performanceButton_Click(object sender, EventArgs e)//performance button
        {
            using (SqlConnection connection = new SqlConnection(connectionString))//exact same as punctuality except replaces punctuality with average performance score
            {
                try
                {
                    string command = "SELECT w.employeeID, e.employeeName, AVG(w.performanceScore) AS averagePerformanceScore FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID GROUP BY w.employeeID, e.employeeName ORDER BY averagePerformanceScore DESC";
                    //Saying AS in the query renames the displayed column to averagePerformanceScore instead of AVG(w.performanceScore)
                    //userInputTextBox.Text = command;
                    SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);
                    DataTable queriedEmployees = new DataTable();
                    sqlda2.Fill(queriedEmployees);

                    dataGridView1.DataSource = queriedEmployees;//fetches result of query, saves it in a local table and displays said table on the data grid view
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void easyTaskAdminPanel_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)//all of these were accidental clicks. The last backup was too far away for me to redo with out accidently clicking these.
        {

        }
    }
}
