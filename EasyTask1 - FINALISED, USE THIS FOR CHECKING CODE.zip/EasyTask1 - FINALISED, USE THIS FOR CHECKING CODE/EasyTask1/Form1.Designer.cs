﻿
namespace EasyTask1
{
    partial class EasyTaskWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.easyTaksLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.buttonUsername = new System.Windows.Forms.Button();
            this.passLabel = new System.Windows.Forms.Label();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.label2023 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // easyTaksLabel
            // 
            this.easyTaksLabel.AutoSize = true;
            this.easyTaksLabel.BackColor = System.Drawing.SystemColors.Window;
            this.easyTaksLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.easyTaksLabel.Location = new System.Drawing.Point(13, 13);
            this.easyTaksLabel.Name = "easyTaksLabel";
            this.easyTaksLabel.Size = new System.Drawing.Size(167, 39);
            this.easyTaksLabel.TabIndex = 0;
            this.easyTaksLabel.Text = "EasyTask";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Location = new System.Drawing.Point(15, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(316, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Work and Team Management Made Easier.";
            // 
            // usernameLabel
            // 
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.BackColor = System.Drawing.SystemColors.Window;
            this.usernameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.usernameLabel.Location = new System.Drawing.Point(19, 172);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(108, 25);
            this.usernameLabel.TabIndex = 2;
            this.usernameLabel.Text = "Username:";
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.usernameTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.usernameTextBox.Location = new System.Drawing.Point(133, 172);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(168, 30);
            this.usernameTextBox.TabIndex = 3;
            // 
            // buttonUsername
            // 
            this.buttonUsername.AutoSize = true;
            this.buttonUsername.BackColor = System.Drawing.SystemColors.Window;
            this.buttonUsername.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonUsername.Location = new System.Drawing.Point(228, 269);
            this.buttonUsername.Name = "buttonUsername";
            this.buttonUsername.Size = new System.Drawing.Size(73, 30);
            this.buttonUsername.TabIndex = 4;
            this.buttonUsername.Text = "Login";
            this.buttonUsername.UseVisualStyleBackColor = false;
            this.buttonUsername.Click += new System.EventHandler(this.buttonUsername_Click);
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.BackColor = System.Drawing.SystemColors.Window;
            this.passLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.passLabel.Location = new System.Drawing.Point(19, 225);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(104, 25);
            this.passLabel.TabIndex = 5;
            this.passLabel.Text = "Password:";
            // 
            // passTextBox
            // 
            this.passTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.passTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.passTextBox.Location = new System.Drawing.Point(133, 220);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.Size = new System.Drawing.Size(168, 30);
            this.passTextBox.TabIndex = 6;
            // 
            // label2023
            // 
            this.label2023.AutoSize = true;
            this.label2023.BackColor = System.Drawing.SystemColors.Window;
            this.label2023.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label2023.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label2023.Location = new System.Drawing.Point(177, 14);
            this.label2023.Name = "label2023";
            this.label2023.Size = new System.Drawing.Size(93, 39);
            this.label2023.TabIndex = 7;
            this.label2023.Text = "2023";
            // 
            // exitButton
            // 
            this.exitButton.AutoSize = true;
            this.exitButton.BackColor = System.Drawing.SystemColors.Window;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.exitButton.Location = new System.Drawing.Point(133, 269);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(79, 30);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // EasyTaskWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::EasyTask1.Properties.Resources._1754305_Website_Background_011;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label2023);
            this.Controls.Add(this.passTextBox);
            this.Controls.Add(this.passLabel);
            this.Controls.Add(this.buttonUsername);
            this.Controls.Add(this.usernameTextBox);
            this.Controls.Add(this.usernameLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.easyTaksLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EasyTaskWindow";
            this.Text = "EasyTask";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label easyTaksLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label usernameLabel;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.Button buttonUsername;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.Label label2023;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Timer timer1;
    }
}

