﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EasyTask1
{
    public partial class FormManageEmployees : Form
    {
        public FormManageEmployees()
        {
            InitializeComponent();
            searchButton.Enabled = false;
            addButton.Enabled = false;
            updateButton.Enabled = false;
            removeButton.Enabled = false;//disables all the buttons at first. This is so that the referesh is hit first, ensuring no errors occur by not allowing the suer to have not dropdown menu item selected
            


            addPanel.Visible = false;
            emptyPanel.Visible = true;
            updatePanel.Visible = false;
            removePanel.Visible = false;//makes the relevant panelts invisible
        }


        private bool comboBoxWasChanged = false;//doesnt do anything, experiment that didnt work out

        string connectionString = "integrated security = true; data source=localhost;initial catalog=EasyTask";//conection string

        private void goBackButton_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();//back button that returns user to the admin panel
            Form2.Show();
            this.Hide();
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string command = "SELECT * FROM Employees";//selects everything from employees
                SqlDataAdapter sqlda = new SqlDataAdapter(command, connection);
                DataTable allEmployeesTable = new DataTable();
                sqlda.Fill(allEmployeesTable);//fills tetmportary table with fetched results

                dataGridView1.DataSource = allEmployeesTable;//fills datagrid view with the fetched data saved in the table

                searchButton.Enabled = true;
                addButton.Enabled = true;
                updateButton.Enabled = true;
                removeButton.Enabled = true;
                sortByCombo.SelectedIndex = 0;
                searchByCombo.SelectedIndex = 0;//upon clicking the refresh button every other button is re-enabled and the comboBox items are automatically set to their first item
                //this is to avoid errors when the user selects nothing. In other words initializes a defult value

            }
        }

        private void searchButton_Click(object sender, EventArgs e)//SEARCH BUTTON
        {
            string userInput = userInputTextBox.Text;
            string searchCombo = searchByCombo.SelectedItem.ToString();   //initializes variables that take in values from textand combo boxes. Later I learnt i can just directly use this without a need for variables
            string sortCombo = sortByCombo.SelectedItem.ToString();
            

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    if (userInput == "")//if no value to be searched is entered
                    {
                        MessageBox.Show("Nothing was entered to be queried, Please make sure you select a search category and enter an appropriate value to be queried.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //tell them to actually enter a value
                    }
                    else
                    {
                        if (searchCombo == "employeeID" || searchCombo == "yearlySalary" || searchCombo == "adminStatus")//this if statement is for appropriate data type usage. If the column to be searched by has a integer constraint:
                        {
                            string command = "SELECT * FROM Employees WHERE " + searchCombo + " = " + userInput + " ORDER BY " + sortCombo + " ASC";//the select statemnt doesnt have a '' around the condition
                            //you can see that the statement selects everything from employees where the column is whatever they picked from the combo box and the value of said column is whatever they wrote fot the search
                            //the data is sorted by whatever they picked for sorting.
                            //userInputTextBox.Text = command;
                            SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);
                            DataTable queriedEmployees = new DataTable();
                            sqlda2.Fill(queriedEmployees);

                            dataGridView1.DataSource = queriedEmployees;//ffill datagrid wth fetched results
                        }
                        else
                        {
                            string command = "SELECT * FROM Employees WHERE " + searchCombo + " = '" + userInput + "' ORDER BY " + sortCombo + " ASC";//otherwise if its not a int, make sure the '' is around the value
                            //userInputTextBox.Text = command;
                            SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);
                            DataTable queriedEmployees = new DataTable();
                            sqlda2.Fill(queriedEmployees);

                            dataGridView1.DataSource = queriedEmployees;//fill data grid
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Something went wrong. \nEnsure the right data type was queried for in accordance to the column data type. Eg: don't search for a string(text) with a numeric search filter like ID or salary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //if an error occurs, then It most probably that they didn't enter the right data type in accordance to the selected column. eg. string for int and it prompts them to fix this
                }
                
            }   
        }

        private void sortByCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxWasChanged = true;//experiment from the code that didnt work. I was gonna detect if it was changed or not and prompt the user to select a value if they hadn't
            //but instead I opted in to select a defult value
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxWasChanged = true;//same as the one above
        }

        private void confirmAddButton_Click(object sender, EventArgs e)//button to add a new user
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();//opens auto closing connection
                try
                {
                    DateTime birthDate = dateTimePicker1.Value.Date;//takes the birthdate from the dattime picker
                    string command = "INSERT INTO Employees VALUES (" + IDTextBox.Text + ", '" + nameTextBox.Text + "', '" + PNTextBox.Text + "', '" + emailTextBox.Text + "', '" + depTextBox.Text + "', @DateSelected, " + adminCombo.SelectedItem + ", " + salaryTextBox.Text + ")";
                    //sets the command to take in everything from the input fields.

                    ///////////////////////////////////////AUTO LOGIN DETAIL GENERATION
                    List<string> password1List = new List<string> {"Ocean", "Sky", "Space", "Cosmos", "Mud", "Earth", "Amazing", "Central", "Oxygenated", "Techno", "DJ", "Fulfilled" };
                    List<string> password2List = new List<string> { "Cow", "Sheep", "Dog", "Crocodile", "Aligator", "Dinosaur", "Cat", "Kitty", "Orangutan", "Chimp", "Ketchup", "Hamburger" };
                    //initializes 2 lists of passwords that will be combined for a password
                    int yearPassword = DateTime.Now.Year;//saves todays year into a variable
                    int getBirthYear = dateTimePicker1.Value.Year;//saves the year of a users birth
                    int yearPasswordActual = yearPassword % 100;//by modding 100, I get just the 23
                    int userNameYear = getBirthYear % 1000; //by modding 1000 i get the last 3 digits of a persons birthyear
                    

                    Random random = new Random();//initializes random method

                    int getPass1 = random.Next(password1List.Count);//function that randomly picks prefix from list1
                    int getPass2 = random.Next(password2List.Count);//function that randomly picks suffix from list2

                    string pass1 = password1List[getPass1];//prefix gotten and saved
                    string pass2 = password2List[getPass2];//suffix gotten and saved

                    string newPassword = pass1 + pass2 + yearPasswordActual.ToString();//sets the new password for the new user to be prefix + suffix + date they joined the company in

                    string fullName = nameTextBox.Text;//takes the full name of the user
                    string nameWithoutSpaces = fullName.Replace(" ", "");//and removes the space in between

                    string userLoginName = nameWithoutSpaces + userNameYear.ToString();//saves the new login to be the full name without spaces and the 3 last digits of the year they were born in to the end

                    string commandLogin = "INSERT INTO LoginDetails VALUES (" + IDTextBox.Text + ", " + IDTextBox.Text + ", '" + userLoginName + "', '" + newPassword + "')";
                    //inserts into login details into login and employee ids whatever is the provided ID for the new user aswell as the new login and password.
                    ///////////////////////////////////////////////////////
                    
                    //ITS BETTER TO STORE PASSWORDS ENCRYPTED USING SHA1 SHA2 MD5


                    using (SqlCommand cmd = new SqlCommand(command, connection))
                    {
                        cmd.Parameters.AddWithValue("@DateSelected", birthDate);
                        cmd.ExecuteNonQuery();//uses this method to be able to bypass errors with adding dates into sql that result in having the time as 00:00:00 instead of just having the date
                        //executes query for adding a new user
                    }

                    SqlCommand cmdlogin = new SqlCommand(commandLogin, connection);
                    cmdlogin.ExecuteNonQuery();//executes the command for auto creating the login for the new user

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//show any potential errors
                }

            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            adminCombo.SelectedIndex = 0;

            addPanel.Visible = true;
            emptyPanel.Visible = false;
            updatePanel.Visible = false;
            removePanel.Visible = false;//on add button click, make the add panel visible and the others invisible
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            upAdmin.SelectedIndex = 0;
            updateByCombo.SelectedIndex = 0;

            addPanel.Visible = false;
            emptyPanel.Visible = false;//make update panel visible and others invisible
            updatePanel.Visible = true;
            removePanel.Visible = false;
        }

        private void removeButton_Click(object sender, EventArgs e)
        {
            removeByCombo.SelectedIndex = 0;
            addPanel.Visible = false;
            emptyPanel.Visible = false;
            updatePanel.Visible = false;//make remove panel visible and others invisible
            removePanel.Visible = true;
        }

        private void updateRecordButton_Click(object sender, EventArgs e)//update record button for actually sending the query
        {
            string updateCombo = updateByCombo.SelectedItem.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    if (updateCombo == "employeeID" || updateCombo == "yearlySalary" || updateCombo == "adminStatus")//if the update category is and integer value
                    {
                        DateTime birthDate = dateTimePicker1.Value.Date;
                        string command = "UPDATE Employees SET employeeID = " + upID.Text + ", employeeName = '" + upName.Text + "', employeePhoneNumber = '" + upPN.Text + "', employeeEmail = '" + upEmail.Text + "', department =  '" + upDep.Text + "', dateOfBirth = @DateSelected, adminStatus = " + upAdmin.SelectedItem + ", yearlySalary = " + upSalary.Text + " WHERE " + updateByCombo.SelectedItem + " = " + updateByValue.Text;
                        //makes the update employee command but the where condition accepts an int value
                        using (SqlCommand cmd = new SqlCommand(command, connection))
                        {
                            cmd.Parameters.AddWithValue("@DateSelected", birthDate);
                            cmd.ExecuteNonQuery();//executes query using special method to avoid errors with date insertion
                        }
                    }

                    else//otherwise if its not an int
                    {
                        DateTime birthDate = dateTimePicker1.Value.Date;
                        string command = "UPDATE Employees SET employeeID = " + upID.Text + ", employeeName = '" + upName.Text + "', employeePhoneNumber = '" + upPN.Text + "', employeeEmail = '" + upEmail.Text + "', department =  '" + upDep.Text + "', dateOfBirth = @DateSelected, adminStatus = " + upAdmin.SelectedItem + ", yearlySalary = " + upSalary.Text + " WHERE " + updateByCombo.SelectedItem + " = '" + updateByValue.Text + "'";
                        //update command but with the value in the where cndition having '' around it for a string
                        using (SqlCommand cmd = new SqlCommand(command, connection))
                        {
                            cmd.Parameters.AddWithValue("@DateSelected", birthDate);
                            cmd.ExecuteNonQuery();//executes query avoiding date error
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//show any potential errors
                }

            }
        }

        private void removeRecordButton_Click(object sender, EventArgs e)
        {
            string removeCombo = removeByCombo.SelectedItem.ToString();//takes in whichever item was selected on the combo box
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    if (removeCombo == "employeeID" || removeCombo == "yearlySalary" || removeCombo == "adminStatus")//once again if the column accepts ints the value doesn't have '' around it otherwise it does have the ''
                    {
                        string command = "DELETE FROM Employees WHERE " + removeByCombo.SelectedItem + " = " + removeByvalue.Text;
                        //sends a delete command based off what the admin chose to be the column to delte by and the value to delete by
                        SqlCommand cmd = new SqlCommand(command, connection);
                        cmd.ExecuteNonQuery();

                        //this wont work due to the referential integrity constraint which I forgot about, I was going to create a trigger to auto delete the corresponding record in LoignDetails
                        //but after some quick research online I learnt about the ON DELETE CASCADE constraint which automatically deletes the corresponding records when a reference record gets deleted.

                        //string command2 = "DELETE FROM LoginDetails WHERE employeeID = (SELECT employeeID FROM LoginDetails WHERE " + removeByCombo.SelectedItem + " = " + removeByvalue.Text + "";
                        //SqlCommand cmd2 = new SqlCommand(command2, connection);
                        //cmd2.ExecuteNonQuery();
                    }
                    else
                    {
                        string command = "DELETE FROM Employees WHERE " + removeByCombo.SelectedItem + " = '" + removeByvalue.Text + "'";
                        SqlCommand cmd = new SqlCommand(command, connection);
                        cmd.ExecuteNonQuery();
                        
                        //string command2 = "DELETE FROM LoginDetails WHERE employeeID = (SELECT employeeID FROM LoginDetails WHERE " + removeByCombo.SelectedItem + " = '" + removeByvalue.Text + "'";
                        //SqlCommand cmd2 = new SqlCommand(command2, connection);
                        //cmd2.ExecuteNonQuery();
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
    }
}
