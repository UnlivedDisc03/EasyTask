﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EasyTask1
{
    public partial class FormReviewWork : Form
    {
        public FormReviewWork()
        {
            InitializeComponent();
            extensionPanel.Visible = false;
            performancePanel.Visible = false;
            panelWork.Visible = false;//disables visibility of all panels at the start
        }


        string connectionString = "integrated security = true; data source=localhost;initial catalog=EasyTask";//connection string

        private void goBackButton_Click(object sender, EventArgs e)//the button to go back to admin menu
        {
            Form2 Form2 = new Form2();
            Form2.Show();
            this.Hide();//allows user to go back to admin main page
        }

        private void checkByUser_Click(object sender, EventArgs e)//this is the search button to look up the submitted work of a specific user
        {
            string userInput = nameTextBox.Text.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    if (userInput == "")//if nothing was entered shows all user tasks
                    {
                        string command = "SELECT w.taskID, w.employeeID, e.employeeName, w.taskDescription, w.dateSet, w.dateDue, w.workComplete, w.workReview AS employeeComment, w.performanceScore, w.punctuality AS punctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID ORDER BY dateDue DESC";
                        //retrieves relevant task information from multiple tables joined together
                        //userInputTextBox.Text = command;
                        SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);
                        DataTable queriedEmployees = new DataTable();
                        sqlda2.Fill(queriedEmployees);

                        dataGridView1.DataSource = queriedEmployees;//fills datagrid
                    }
                    else
                    {
                        //otherwise if a name was entered just search for the tasks where employeeName = entered name
                        string command = "SELECT w.taskID, w.employeeID, e.employeeName, w.taskDescription, w.dateSet, w.dateDue, w.workComplete, w.workReview AS employeeComment, w.performanceScore, w.punctuality AS punctuality FROM WorkSet w INNER JOIN Employees e ON w.employeeID = e.employeeID WHERE e.employeeName = '" + userInput + "' ORDER BY dateDue DESC";
                        //userInputTextBox.Text = command;
                        SqlDataAdapter sqlda2 = new SqlDataAdapter(command, connection);
                        DataTable queriedEmployees = new DataTable();
                        sqlda2.Fill(queriedEmployees);

                        dataGridView1.DataSource = queriedEmployees;//fill datagrid
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//error message in case there is one
                }
            }
        }

        private void extensionButton_Click(object sender, EventArgs e)//give extension button that shows the panel
        {
            extensionPanel.Visible = true;
            performancePanel.Visible = false;
            panelWork.Visible = false;//show up extension panel hide the rest
        }

        private void updateRecordButton_Click(object sender, EventArgs e)//give extension button click
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {

                    DateTime extensionDue = dueDate.Value.Date;
                    string command = "UPDATE WorkSet SET dateDue = @extensionDue, workComplete = 'NO', performanceScore = NULL, punctuality = NULL WHERE taskID = " + taskIDText.Text;
                    //update the records due date and set the workComplete back to no. this is for giving out extensions

                    using (SqlCommand cmd = new SqlCommand(command, connection))
                    {
                        cmd.Parameters.AddWithValue("@extensionDue", extensionDue);
                        cmd.ExecuteNonQuery();
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            extensionPanel.Visible = false;
            performancePanel.Visible = true;//opens performance panel hides the others
            panelWork.Visible = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))//performance button for scoring work submitted
            {
                connection.Open();
                try
                {
                    string command = "UPDATE WorkSet SET performanceScore = " + performanceText.Text  + " WHERE taskID = " + taskIDText2.Text;
                    //sets the performance score for a given task

                    SqlCommand cmd = new SqlCommand(command, connection);
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e) //view work button
        {
            panelWork.Visible = true;
            extensionPanel.Visible = false;
            performancePanel.Visible = false;//the panel for reading the work from the column. I didn't have this originally but realised long comments on completed tasks not only where not visible in the collumn
            //but also if they were too long they ended at "..." after reaching the edge of your screen in the column preview

            workReviewText.ReadOnly = true; //sets the scrollable text box where the users comment goes to read only
        }

        private void button6_Click(object sender, EventArgs e)//no longer exists
        {
            string sample = "sample";
            if (sample == "sample")//broken peice of code, gave it something so It wouldnt cause warnings for being empty
            {
                sample = "sample2";
            }
           
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))//this is the button to see the work comment in full
            {
                connection.Open();
                try
                {
                    string command = "SELECT workReview FROM WorkSet WHERE taskID = " + taskIDForWorkView.Text;
                    //populates a read only large scrollable text box with the full comment submitted by the user. 

                    SqlCommand cmd = new SqlCommand(command, connection);
                    string employeeComment =  cmd.ExecuteScalar()?.ToString();//saves the employee comment and turns it to a string from an object

                    workReviewText.Text = employeeComment; //sets the text box to the object

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"an error occured: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
